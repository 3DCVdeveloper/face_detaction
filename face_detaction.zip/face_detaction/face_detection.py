#!/usr/bin/env python3
# coding=utf-8

import cv2,cv_bridge
import rospy
import numpy as np
import mediapipe as mp
from sensor_msgs.msg import Image
from vision_utils import fps
import gc
from sensor_msgs.msg import Image as ROSImage
import ros_numpy
import math
import sys

"""def save_depth_image_as_txt(depth_image, filepath):
    if depth_image.naim != 2:
        raise ValueError("depth_image must be a 2D numpy array")
    with open(filepath,'w')as file:
        for row in depth_image:
            p
            ros_str = ''.join(map(str,row))
            file.write(row_str + '\n')
"""
def calculate_mse(block):
    valid_values = block[block > 0]  # 忽略深度为0的值
    if valid_values.size > 0:  # 确保存在有效值
        mean_depth = np.mean(valid_values)
        squared_diff = np.square(valid_values - mean_depth)
        mse = np.mean(squared_diff)
        return mse
    else:
        # 如果没有有效值，返回一个默认值
        return 0

def find_noise(blocks):

    noise_block = blocks[4]

    # 统计深度值的分布，忽略深度值为0的数据
    depth_values = noise_block[noise_block > 0]

    # 构造字典，键是深度值，值是该深度值出现的次数
    depth_dict = {}
    for value in depth_values:
        if value in depth_dict:
            depth_dict[value] += 1
        else:
            depth_dict[value] = 1

    # 对字典按键值排序
    sorted_depth_dict = dict(sorted(depth_dict.items()))

    # 确定最大值和最小值
    min_depth = None
    max_depth = None

    # 寻找最小值
    for key in sorted_depth_dict.keys():
        if sorted_depth_dict[key] >= 1:
            min_depth = key
            break

    # 寻找最大值
    for key in sorted(sorted_depth_dict.keys(), reverse=True):
        if sorted_depth_dict[key] >= 1:
            max_depth = key
            break

    # 计算最大值与最小值之差 k
    k = max_depth - min_depth

    # 判断是否为平面（欺骗攻击）
    is_deception = k < 1.5
    return is_deception

def crop_invalid_data(image):
        min_row, max_row = 0, image.shape[0]-1
        min_col, max_col = 0, image.shape[1]-1

        for row in range(image.shape[0]):
            if np.any(~np.isnan(image[row,:]))>20:
                min_row = row 
                break

        for row in reversed(range(image.shape[0])):
            if np.any(~np.isnan(image[row,:]))>20:
                max_row = row 
                break

        for col in range(image.shape[1]):
            if np.any(~np.isnan(image[:,col]))>20:
                min_col = col  
                break

        for col in reversed(range(image.shape[1])):
            if np.any(~np.isnan(image[:,col]))>20:
                max_col = col 
                break 

        if min_row <= max_row and min_col <=max_col:
            cropped_image = image[min_row:max_row+1,min_col:max_col+1]
        else:
            cropped_image = np.full((image.shape[0],image.shape[1]), np.nan)

        return cropped_image

class FaceDetectNode:
    def __init__(self):
        rospy.init_node("face_detect_node",anonymous=True)
        self.camera_rgb_prefix = rospy.get_param('/camera_rgb_prefix', 'camera/rgb')
        self.image_sub = rospy.Subscriber(self.camera_rgb_prefix + '/image_raw', Image, self.image_callback, queue_size=1)
        #self.depth_image = None
        self.bridge = cv_bridge.CvBridge()
        self.count = 0
        self.acc_count = 0
        self.opt = 0
        self.depth_msg = rospy.Subscriber('/camera/depth/image', ROSImage, self.depth_callback)
        #self.result_image = None
        self.trials = 30
        self.filepath = r'Desktop/data/depth_image.txt'
        self.color = [(0, 0, 255), (255, 0, 0), (0, 255, 0)]
        self.detector = cv2.FaceDetectorYN.create("/home/hiwonder/rospider/src/s1fspider/scripts/face_detection_yunet_2022mar.onnx","",
            (320, 240), # 设置检测器处理的图像大小wh
            score_threshold=0.99, # 阈值，应<1，越大误检测越少
            )
        
    def image_callback(self, ros_image):
        if self.opt == 1:
            return
        # self.get_logger().debug('Received an image! ')
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, buffer=ros_image.data) # 原始 RGB 画面
        rgb_image = cv2.cvtColor(rgb_image, cv2.COLOR_BGR2RGB)
        
        self.thum_w=320
        self.blocks = []
        self.result_image = np.copy(rgb_image) # 拷贝一份用作结果显示，以防处理过程中修改了图像
        self.thum_h=int(self.result_image.shape[0]*(self.thum_w/self.result_image.shape[1]))
        self.thum_image = cv2.resize(self.result_image,(self.thum_w,self.thum_h))
        try:
            #cv2.imshow('rgb',rgb_image)
            #cv2.waitKey(1)
            faces = self.detector.detect(self.thum_image)

            #print(faces)
            # 判断是否是真人的脸
            if faces is not None:
                face_flags = []
                thickness = 2

                for idx, face in enumerate(faces[1]):
                        # 人脸框和5点关键点数据
                        # print(faces)
                        coords = face[:-1].astype(np.int32)
                        # print(coords)
                        std = -1
                        dist = []
                        h, w = self.crop_depth_image.shape
                        
                        if h % 3 != 0 or w % 3 != 0:
                            # 计算补零的数量
                            pad_top = (3 - h % 3) // 2
                            pad_bottom = (3 - h % 3) - pad_top
                            pad_left = (3 - w % 3) // 2
                            pad_right = (3 - w % 3) - pad_left
                        else:
                            pad_top = pad_bottom = pad_left = pad_right = 0
                        # 补零
                        if pad_top > 0 or pad_bottom > 0 or pad_left > 0 or pad_right > 0:
                            Crop_depth_image = np.pad(self.crop_depth_image,
                                                      ((pad_top, pad_bottom), (pad_left, pad_right)),
                                                      mode='constant')
                        else:
                            Crop_depth_image = self.crop_depth_image
                        height, width = Crop_depth_image.shape
                        area_height = height // 3
                        area_width = width // 3
                        # 分割数组并存储在字典中
                        for i in range(3):
                            for j in range(3):
                                # 提取每个块
                                start_row = i * area_height
                                end_row = (i + 1) * area_height
                                start_col = j * area_width
                                end_col = (j + 1) * area_width
                                block = Crop_depth_image[start_row: end_row, start_col: end_col]
                                # 将块存储在字典中
                                self.blocks.append(block)
                        noise = find_noise(self.blocks)
                        if noise != 0:
                            self.count +=1
                            print("!!!warning!!!fake!!!")

                            face_flags.append(-1)
                        else:
                            mse_block1 = calculate_mse(self.blocks[1])
                            mse_block3 = calculate_mse(self.blocks[3])
                            mse_block5 = calculate_mse(self.blocks[5])
                            mse_block7 = calculate_mse(self.blocks[7])
                            # 定义权重
                            weights = np.array([0.1, 0.3, 0.3, 0.3])

                            # 计算加权均方差
                            mse_values = np.array([mse_block1, mse_block3, mse_block5, mse_block7])
                            weighted_mse = np.sum(mse_values * weights)

                            # 设置阈值
                            threshold = 0.1
                            if weighted_mse > threshold:
                                face_flags.append(1)
                                self.acc_count += 1
                                self.count += 1
                                #print(self.count)
                            else:
                                face_flags.append(-1)
                                self.count += 1
                            # 输出结果
                            print("加权均方差:", weighted_mse)

                        """

                        # 5个点关键点到相机的距离（单位mm）
                        for i in range(2, 7):
                            if 0 <= coords[2*i] < w and 0 <= coords[2*i+1] < h:
                                dist.append(self.crop_depth_image[coords[2*i+1], coords[2*i]])
                                dist = [0 if math.isnan(x) else x for x in dist]# 把nan变0
                                #print('location:',coords[8],coords[9])
                                #print(dist)
                                #print(i)
                            if len(dist) == 5: # 计算全部5个关键点到相机的距离的均方差
                                dist = list(np.array(dist) * 100) #放大100
                                
                                std = np.std(dist)
                                #print(std)
                          



                        # 使用限制条件：人脸正对相机
                        if std < 0 : # 未判断
                            face_flags.append(0)
                            self.count+=1

                        elif std < 1: # 伪造
                            face_flags.append(-1)
                            self.count+=1

                        else: # 真人
                            face_flags.append(1)
                            self.count+=1
                            self.acc_count+=1

                        #每一张脸
                        
                        """
                        # 蓝色-未判断；红色-伪造；绿色-真人
                        cv2.rectangle(self.thum_image, (coords[0], coords[1]),
                                      (coords[0] + coords[2], coords[1] + coords[3]), self.color[face_flags[idx] + 1],
                                      thickness)
                        # 绘制5个关键点
                        cv2.circle(self.thum_image, (coords[4], coords[5]), 2, (255, 0, 0), thickness)
                        cv2.circle(self.thum_image, (coords[6], coords[7]), 2, (0, 0, 255), thickness)
                        cv2.circle(self.thum_image, (coords[8], coords[9]), 2, (0, 255, 0), thickness)
                        cv2.circle(self.thum_image, (coords[10], coords[11]), 2, (255, 0, 255), thickness)
                        cv2.circle(self.thum_image, (coords[12], coords[13]), 2, (0, 255, 255), thickness)
                        
                        if self.count == self.trials:
                            acc = (self.acc_count / self.count)*100
                            self.count = 0
                            self.acc_count = 0
                            print(f"活体率： {acc:.2f}%")
                        if acc >= 80:
                            print("人类！是人类！")
                        else:
                            print("非活体攻击！！")
                        self.opt = 1
            else:
                print('no face')
        except Exception as e:
            #rospy.logerr(str(e))
            print('faces')

        cv2.imshow("RGB_Image", self.thum_image)  
        cv2.waitKey(1)


    def depth_callback(self,depth_msg):
        self.depth_image = ros_numpy.numpify(depth_msg)
        self.cropped_image1 = cv2.resize(self.depth_image,(320,240))
        self.cropped_image0 = crop_invalid_data(self.cropped_image1)
        self.crop_depth_image = np.where(np.isnan(self.cropped_image0),0,self.cropped_image0)


if __name__ == "__main__":
    try:
        face_detection_node = FaceDetectNode()

        rospy.spin()

    except Exception as e:
        rospy.logerr(str(e))