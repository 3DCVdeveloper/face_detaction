#!/usr/bin/env python3
# coding=utf-8

import cv2,cv_bridge
import rospy
import numpy as np
import mediapipe as mp
from sensor_msgs.msg import Image
from vision_utils import fps
import gc
from sensor_msgs.msg import Image as ROSImage
import ros_numpy


class FaceDetectNode:
    def __init__(self):
        rospy.init_node("face_detect_node")
        self.camera_rgb_prefix = rospy.get_param('/camera_rgb_prefix', 'camera/rgb')
        self.image_sub = rospy.Subscriber(self.camera_rgb_prefix + '/image_raw', Image, self.image_callback, queue_size=1)
        self.depth_image = None
        self.bridge = cv_bridge.CvBridge()
        self.depth_sub = rospy.Subscriber('/camera/depth/image', ROSImage, self.depth_callback)
		self.result_image = None
    def image_callback(self, ros_image):
        # self.get_logger().debug('Received an image! ')
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, buffer=ros_image.data) # 原始 RGB 画面
        result_image = np.copy(rgb_image) # 拷贝一份用作结果显示，以防处理过程中修改了图像
        try:
            print('11111111')

        except Exception as e:
            rospy.logerr(str(e))

        cv2.imshow('image', result_image)
        cv2.waitKey(1)
        gc.collect()
        return result_image
    def depth_callback(self,depth_msg,result_image):
        depth_image = ros_numpy.numpify(depth_msg)
        print(result_image)            
    


#    def get_facial_keypoints(self, depth_image):

if __name__ == "__main__":

    try:
        face_detection_node = FaceDetectNode()
        rospy.spin()

    except Exception as e:
        rospy.logerr(str(e))
