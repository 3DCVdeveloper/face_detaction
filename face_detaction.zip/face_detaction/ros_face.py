#!/usr/bin/env python3
# coding=utf-8

import cv2,cv_bridge
import rospy
import numpy as np
import mediapipe as mp
from sensor_msgs.msg import Image
from vision_utils import fps
import gc
from sensor_msgs.msg import Image as ROSImage
import ros_numpy
import math


class FaceDetectNode:
    def __init__(self):
        rospy.init_node("face_detect_node")
        self.camera_rgb_prefix = rospy.get_param('/camera_rgb_prefix', 'camera/rgb')
        self.image_sub = rospy.Subscriber(self.camera_rgb_prefix + '/image_raw', Image, self.image_callback, queue_size=1)
        #self.depth_image = None
        self.bridge = cv_bridge.CvBridge()
        self.depth_sub = rospy.Subscriber('/camera/depth/image', ROSImage, self.depth_callback)
        #self.result_image = None
        self.color = [(0, 0, 255), (255, 0, 0), (0, 255, 0)]
        self.detector = cv2.FaceDetectorYN.create("face_detection_yunet_2022mar.onnx","",
            (320, 240), # 设置检测器处理的图像大小wh
            score_threshold=0.99, # 阈值，应<1，越大误检测越少
            )
        #self.thum_w=200
        #self.thum_h=int(self.result_image.shape[0]*(thum_w/self.result_image.shape[1]))
        #@self.thum_image = cv2.resize(self.result_image,(thum_w,thum_h))
        
    def image_callback(self, ros_image):
        # self.get_logger().debug('Received an image! ')
        rgb_image = np.ndarray(shape=(ros_image.height, ros_image.width, 3), dtype=np.uint8, buffer=ros_image.data) # 原始 RGB 画面
        rgb_image = cv2.cvtColor(rgb_image, cv2.COLOR_BGR2RGB)
        crop_image = cv2.resize(rgb_image, (rgb_image.shape[1] // 2, rgb_image.shape[0] // 2))
        self.result_image = np.copy(crop_image) # 拷贝一份用作结果显示，以防处理过程中修改了图像
        try:
            #cv2.imshow('rgb',rgb_image)
            #cv2.waitKey(1)
            faces = self.detector.detect(self.result_image)
            #print(faces)
            # 判断是否是真人的脸
            if faces is not None:
                face_flags = []
                thickness = 2
                #每一张脸
                for idx, face in enumerate(faces[1]):
                    # 人脸框和5点关键点数据
                    coords = face[:-1].astype(np.int32)
                    std = -1
                    dist = []
                    h, w = self.depth_image.shape
                    # 5个点关键点到相机的距离（单位mm）
                    for i in range(2, 7):
                        if 0 <= coords[2*i] < w and 0 <= coords[2*i+1] < h:
                            dist.append(self.depth_image[coords[2*i+1], coords[2*i]])
                            dist = [0 if math.isnan(x) else x for x in dist]# 把nan变0
                        if len(dist) == 5: # 计算全部5个关键点到相机的距离的均方差
                            dist = list(np.array(dist) * 1000) #放大1000
                            #print(dist)
                            std = np.std(dist)
                            #print(std)
                            print("std: {:.2f}".format(std))
                    # 使用限制条件：人脸正对相机
                    if std < 0: # 未判断
                        face_flags.append(0)
                    elif std < 10: # 伪造
                        face_flags.append(-1)
                    else: # 真人
                        face_flags.append(1)
                    #每一张脸
            for idx, face in enumerate(faces[1]):
                # 人脸框和5点关键点数据
                coords = face[:-1].astype(np.int32)
                # 绘制人脸框
                # 蓝色-未判断；红色-伪造；绿色-真人
                cv2.rectangle(self.result_image, (coords[0], coords[1]), (coords[0]+coords[2], coords[1]+coords[3]), self.color[face_flags[idx]+1], thickness)
                # 绘制5个关键点
                cv2.circle(self.result_image, (coords[4], coords[5]), 2, (255, 0, 0), thickness)
                cv2.circle(self.result_image, (coords[6], coords[7]), 2, (0, 0, 255), thickness)
                cv2.circle(self.result_image, (coords[8], coords[9]), 2, (0, 255, 0), thickness)
                cv2.circle(self.result_image, (coords[10], coords[11]), 2, (255, 0, 255), thickness)
                cv2.circle(self.result_image, (coords[12], coords[13]), 2, (0, 255, 255), thickness)
            cv2.imshow("RGB_Image", self.result_image)  
            cv2.waitKey(1)
        except Exception as e:
            #rospy.logerr(str(e))
            print('no targe')

    def depth_callback(self,depth_msg):
        self.depth_image = ros_numpy.numpify(depth_msg)
                    
        


if __name__ == "__main__":

    try:
        face_detection_node = FaceDetectNode()
        rospy.spin()

    except Exception as e:
        rospy.logerr(str(e))